# THE SURVIVORS — APK FINAL (BuildKit)

Acesta este un **BuildKit** care produce APK prin **GitHub Actions (fără PC)** sau local.
Nu este APK-ul deja compilat (compilarea/semnarea se face într-un mediu Android/CI).

## A) Fără PC — GitHub Actions (recomandat)
1. Creează un repo nou pe GitHub (ex: `the-survivors-apk`).
2. Uploadează TOT folderul `the-survivors-apk-buildkit/` în repo (inclusiv `.github/`).
3. GitHub → **Actions** → rulează workflow: **Build Android APK**
4. Descarcă artifact-ul: **app-debug.apk**

## B) Local (PC)
Necesare: Node 20+, Java 17, Android Studio / SDK
```bash
npm install
npm run build:android
```
APK debug: `android/app/build/outputs/apk/debug/app-debug.apk`

## Icon + Splash
Sunt în `resources/` și se generează automat în Android res de:
`npm run assets:android`
