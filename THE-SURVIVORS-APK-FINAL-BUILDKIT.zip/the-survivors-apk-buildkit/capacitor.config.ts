import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thesurvivors.pilot',
  appName: 'THE SURVIVORS',
  webDir: 'web',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' }
};

export default config;
