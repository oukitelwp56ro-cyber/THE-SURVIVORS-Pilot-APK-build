// THE SURVIVORS — Pilot PWA (local-first)
// Modules: Adaptive Delay (SHORT), Position Size, Micro Timing, Exit Engine, Journal, Live Proof,
// UI: Explicit Analyzing Flow + Fail State + Lock Screen Mode + Cooldown Auto-Unlock UX + Toast.
// No cloud. Storage: localStorage.

const $ = (id) => document.getElementById(id);

const LS = {
  lang: "ts_lang",
  journal: "ts_journal",
  locks: "ts_locks",
  wizard: "ts_wizard",
  ai: "ts_ai",
  exec: "ts_exec",
  prefs: "ts_prefs",
  profiles: "ts_profiles",
  currentProfile: "ts_current_profile"
};

const state = {
  lang: "ro",
  i18n: {},
  lockedUntil: 0,
  countdown: null,
  countdownEndsAt: 0,
  step1Done: false,
  wizardStep: 1,
  inputsLocked: false,
  execEndsAt: 0,
  execTicker: null,
  market: "NATGAS",
  platform: "XTB",
  profileId: null,
  profileName: ""
};


function keyFor(kind){
  // Namespaced storage per profile
  const pid = state.profileId || "default";
  if(kind === "journal") return `ts_journal_${pid}`;
  if(kind === "locks") return `ts_locks_${pid}`;
  if(kind === "wizard") return `ts_wizard_${pid}`;
  if(kind === "ai") return `ts_ai_${pid}`;
  if(kind === "exec") return `ts_exec_${pid}`;
  if(kind === "prefs") return `ts_prefs_${pid}`;
  return `ts_${kind}_${pid}`;
}

function defaultProfiles(){
  return [
    { id:"p_natgas_xtb", name:"NATGAS • XTB", market:"NATGAS", platform:"XTB", mode:"CONSERVATOR", guard:120 },
    { id:"p_oil_mt5", name:"OIL • MT5", market:"OIL", platform:"MT5", mode:"CONSERVATOR", guard:120 },
    { id:"p_gold_ibkr", name:"GOLD • IBKR", market:"GOLD", platform:"IBKR", mode:"CONSERVATOR", guard:120 }
  ];
}

function loadProfiles(){
  try{
    const raw = localStorage.getItem(LS.profiles);
    if(!raw){
      const list = defaultProfiles();
      localStorage.setItem(LS.profiles, JSON.stringify(list));
      return list;
    }
    const list = JSON.parse(raw);
    if(!Array.isArray(list) || !list.length){
      const d = defaultProfiles();
      localStorage.setItem(LS.profiles, JSON.stringify(d));
      return d;
    }
    return list;
  }catch{
    const d = defaultProfiles();
    localStorage.setItem(LS.profiles, JSON.stringify(d));
    return d;
  }
}

function saveProfiles(list){
  localStorage.setItem(LS.profiles, JSON.stringify(list));
}

function getCurrentProfileId(){
  return localStorage.getItem(LS.currentProfile) || null;
}

function setCurrentProfileId(id){
  localStorage.setItem(LS.currentProfile, id);
}

function findProfile(list, id){
  return list.find(p => p.id === id) || list[0];
}

function nowTs(){ return Date.now(); }
function fmtTime(ms){
  const s = Math.max(0, Math.ceil(ms/1000));
  return `${s}s`;
}

function loadLocks(){
  try{
    const raw = localStorage.getItem(keyFor("locks"));
    if(!raw) return;
    const obj = JSON.parse(raw);
    state.lockedUntil = obj.lockedUntil || 0;
  }catch{}
}
function loadWizard(){
  try{
    const raw = localStorage.getItem(keyFor("wizard"));
    if(!raw) return;
    const obj = JSON.parse(raw);
    state.wizardStep = obj.step || 1;
  }catch{}
}
function saveWizard(){
  localStorage.setItem(keyFor("wizard"), JSON.stringify({ step: state.wizardStep }));
}
function loadAI(){
  try{
    return JSON.parse(localStorage.getItem(keyFor("ai")) || "{}");
  }catch{
    return {};
  }
}
function saveAI(obj){
  localStorage.setItem(keyFor("ai"), JSON.stringify(obj || {}));
}

function loadPrefs(){
  try{
    const raw = localStorage.getItem(keyFor("prefs"));
    if(!raw) return;
    const obj = JSON.parse(raw);
    state.market = obj.market || state.market;
    state.platform = obj.platform || state.platform;
  }catch{}
}
function savePrefs(){
  localStorage.setItem(keyFor("prefs"), JSON.stringify({ market: state.market, platform: state.platform }));
}

function saveLocks(){
  localStorage.setItem(keyFor("locks"), JSON.stringify({ lockedUntil: state.lockedUntil }));
}

function getJournal(){
  try{
    return JSON.parse(localStorage.getItem(keyFor("journal")) || "[]");
  }catch{
    return [];
  }
}
function setJournal(list){
  localStorage.setItem(keyFor("journal"), JSON.stringify(list));
  renderJournal();
  renderKPI();
}

async function loadI18n(lang){
  const resp = await fetch(`./i18n/${lang}.json`);
  const json = await resp.json();
  state.i18n = json;
  state.lang = lang;
  localStorage.setItem(LS.lang, lang);
  document.documentElement.lang = lang;
  applyI18n();
}

function t(key){
  return state.i18n[key] || key;
}

function applyI18n(){
  $("subtitle").textContent = t("subtitle");
  $("cardStatusTitle").textContent = t("status");
  $("cardInputTitle").textContent = t("inputs");
  $("cardTradeTitle").textContent = t("trade");
  $("cardJournalTitle").textContent = t("journal");

  $("lblEdge").textContent = t("edge");
  $("lblProb").textContent = t("prob");
  $("lblVerdict").textContent = t("verdict");
  $("lblTiming").textContent = t("timing");
  $("lblSize").textContent = t("size");
  $("lblDelay").textContent = t("delay");
  $("lblVol").textContent = t("vol");
  $("lblRegime").textContent = t("regime");

  $("calcBtn").textContent = t("calc");
  $("startBtn").textContent = t("open");
  $("blockBtn").textContent = t("lock");
  $("cdTitle").textContent = t("countdown");
  $("step1Btn").textContent = t("step1");
  $("step2Btn").textContent = t("step2");

  $("tEntry").textContent = t("entry");
  $("tSL").textContent = t("sl");
  $("tDir").textContent = t("direction");
  $("tPeak").textContent = t("peak");
  $("tNow").textContent = t("now");
  $("tTP1hit").textContent = t("tp1hit");

  $("evalExitBtn").textContent = t("evalExit");
  $("closeBtn").textContent = t("closeLog");

  $("exportBtn").textContent = t("export");
  $("clearJournalBtn").textContent = t("clear");
  $("resetBtn").textContent = t("reset");
}

function registerSW(){
  if("serviceWorker" in navigator){
    navigator.serviceWorker.register("./sw.js").catch(()=>{});
  }
}

/* -------------------- TOAST -------------------- */
let toastTimer = null;
function showToast(msg, kind="warn", ms=2200){
  $("toastMsg").textContent = msg;
  $("toast").hidden = false;
  $("toast").classList.remove("warn","show");
  if(kind === "warn") $("toast").classList.add("warn");
  $("toast").classList.add("show");

  if(toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    $("toast").hidden = true;
  }, ms);
}


/* -------------------- REQUIREMENTS ENGINE -------------------- */
const APPS = {
  TRADINGVIEW: {
    name:"TradingView",
    why:"Chart + levels",
    open:"https://www.tradingview.com",
    intent:"intent://www.tradingview.com/#Intent;scheme=https;package=com.tradingview.tradingviewapp;end",
    play:"market://details?id=com.tradingview.tradingviewapp"
  },
  INVESTING: {
    name:"Investing.com",
    why:"Watchlist NG/MND/VIX/DXY + calendar",
    open:"https://www.investing.com",
    intent:"intent://www.investing.com/#Intent;scheme=https;package=com.fusionmedia.investing;end",
    play:"market://details?id=com.fusionmedia.investing"
  },
  WINDY: {
    name:"Windy",
    why:"Meteo (NOAA/ECMWF) — critical for NATGAS",
    open:"https://www.windy.com",
    intent:"intent://www.windy.com/#Intent;scheme=https;package=com.windyty.android;end",
    play:"market://details?id=com.windyty.android"
  },
  REUTERS: {
    name:"Reuters",
    why:"Tier-A news confirmation",
    open:"https://www.reuters.com",
    intent:null,
    play:null
  },
  BLOOMBERG: {
    name:"Bloomberg",
    why:"Tier-A news confirmation",
    open:"https://www.bloomberg.com",
    intent:"intent://www.bloomberg.com/#Intent;scheme=https;package=com.bloomberg.android.plus;end",
    play:"market://details?id=com.bloomberg.android.plus"
  },
  XTB: {
    name:"XTB",
    why:"Execution platform",
    open:"https://www.xtb.com",
    intent:"intent://www.xtb.com/#Intent;scheme=https;package=com.xtb.xtb;end",
    play:"market://details?id=com.xtb.xtb"
  },
  MT5: {
    name:"MetaTrader 5",
    why:"Execution platform",
    open:"https://www.metatrader5.com",
    intent:"intent://www.metatrader5.com/#Intent;scheme=https;package=net.metaquotes.metatrader5;end",
    play:"market://details?id=net.metaquotes.metatrader5"
  },
  CTRADER: {
    name:"cTrader",
    why:"Execution platform",
    open:"https://ct.trader",
    intent:"intent://ct.trader/#Intent;scheme=https;package=com.spotware.ct;end",
    play:"market://details?id=com.spotware.ct"
  },
  IBKR: {
    name:"Interactive Brokers",
    why:"Execution platform",
    open:"https://www.interactivebrokers.com",
    intent:"intent://www.interactivebrokers.com/#Intent;scheme=https;package=com.interactivebrokers.mobile;end",
    play:"market://details?id=com.interactivebrokers.mobile"
  }
};

function requirementsFor(market, platform){
  const list = [];
  // Base (always)
  list.push("TRADINGVIEW");
  list.push("INVESTING");

  // Market-specific
  if(market === "NATGAS") list.push("WINDY");
  // Optional news tier for all (pilot recommends but doesn't hard-block)
  list.push("REUTERS");
  list.push("BLOOMBERG");

  // Platform-specific
  if(platform === "XTB") list.push("XTB");
  if(platform === "MT5") list.push("MT5");
  if(platform === "CTRADER") list.push("CTRADER");
  if(platform === "IBKR") list.push("IBKR");

  // De-dup
  return [...new Set(list)];
}

function renderRequirements(){
  const market = state.market || ($("marketIn") ? $("marketIn").value : "NATGAS");
  const platform = state.platform || ($("platformIn") ? $("platformIn").value : "XTB");
  const req = requirementsFor(market, platform);

  $("reqSub").textContent = `Market: ${market} • Platform: ${platform}`;
  const wrap = $("reqList");
  wrap.innerHTML = "";

  req.forEach(key=>{
    const a = APPS[key];
    const row = document.createElement("div");
    row.className = "reqItem";
    row.innerHTML = `
      <div class="reqMeta">
        <div class="reqName">${a.name} <span class="badge">${key}</span></div>
        <div class="reqWhy">${a.why}</div>
      </div>
      <div class="reqBtns">
        <button class="btn ghost" data-open="${key}">OPEN</button>
        <button class="btn" data-install="${key}">INSTALL</button>
      </div>
    `;
    wrap.appendChild(row);
  });

  // bind
  wrap.querySelectorAll("[data-open]").forEach(btn=>{
    btn.addEventListener("click", () => {
      const k = btn.getAttribute("data-open");
      const a = APPS[k];
      openDeepLink(a.open, a.intent || null);
    });
  });
  wrap.querySelectorAll("[data-install]").forEach(btn=>{
    btn.addEventListener("click", () => {
      const k = btn.getAttribute("data-install");
      const a = APPS[k];
      if(a.play){
        // play store deep link
        try{ window.location.href = a.play; }
        catch{ window.open(a.open, "_blank"); }
      }else{
        // no play id known → open website
        window.open(a.open, "_blank");
      }
    });
  });
}

function reqHardBlockIfUnconfirmed(out){
  // Pilot rule: if user didn't confirm required apps, block DA (procedural).
  // Rationale: prevents execution without tools.
  if(out && out.verdict === "DA"){
    const ok = $("reqConfirmed") ? $("reqConfirmed").checked : true;
    if(!ok){
      out.verdict = "NU";
      out.reasonNote = "Required apps not confirmed";
    }
  }
  return out;
}

/* -------------------- EXECUTION LINK -------------------- */
function openDeepLink(url, intentFallback){
  // Best effort: open external app via URL/intent. No broker control.
  try{
    // Android intent fallback if provided
    if(intentFallback && /Android/i.test(navigator.userAgent)){
      window.location.href = intentFallback;
      return;
    }
    window.open(url, "_blank");
  }catch(e){
    console.log("DEEPLINK ERROR", e);
  }
}

function allExecChecksDone(){
  return ["ex1","ex2","ex3","ex4"].every(id => $(id).checked);
}

function updateExecDoneButton(){
  $("execDoneBtn").disabled = !allExecChecksDone();
}

function showExecSheet(){
  $("execOverlay").hidden = false;
  const p = (state.platform || ($("platformIn") ? $("platformIn").value : "XTB"));
  $("openXtbBtn").textContent = `OPEN ${p}`;
  $("execSub").textContent = `Guard 120s • ${p} • Checklist`;

  // guard 120s
  const g = (state.guardSec || 120);
  state.execEndsAt = nowTs() + g*1000;
  if(state.execTicker) clearInterval(state.execTicker);
  state.execTicker = setInterval(() => {
    const ms = state.execEndsAt - nowTs();
    if(ms <= 0){
      $("execTimerPill").textContent = "GUARD: 0s";
      clearInterval(state.execTicker);
      state.execTicker = null;
      // keep sheet open; user must re-check via Wizard / CALC if too late
      return;
    }
    $("execTimerPill").textContent = `GUARD: ${fmtTime(ms)}`;
  }, 250);
  $("execTimerPill").textContent = `GUARD: ${state.guardSec || 120}s`;

  // reset checks
  ["ex1","ex2","ex3","ex4"].forEach(id => { $(id).checked = false; });
  updateExecDoneButton();
}

function hideExecSheet(){
  $("execOverlay").hidden = true;
  if(state.execTicker){ clearInterval(state.execTicker); state.execTicker = null; }
}

function guardExpired(){
  return nowTs() > state.execEndsAt;
}

function getExecLog(){
  try{ return JSON.parse(localStorage.getItem(keyFor("exec")) || "[]"); }catch{ return []; }
}
function pushExecLog(rec){
  const list = getExecLog();
  list.unshift(rec);
  localStorage.setItem(keyFor("exec"), JSON.stringify(list));
}

/* -------------------- LOCK OVERLAY -------------------- */
let lockTicker = null;
function showLockOverlay(reasonText){
  $("lockReason").textContent = reasonText || "RULE BLOCK";
  $("lockOverlay").hidden = false;
  $("startBtn").disabled = true; // hard disable OPEN while visible
  updateLockOverlayTimer();
  if(lockTicker) clearInterval(lockTicker);
  lockTicker = setInterval(updateLockOverlayTimer, 500);
}
function hideLockOverlay(){
  $("lockOverlay").hidden = true;
  if(lockTicker) { clearInterval(lockTicker); lockTicker = null; }
}
let unlockedShown = false;

function updateLockOverlayTimer(){
  const overlay = $("lockOverlay");
  const badge = $("lockBadge");
  const recheck = $("recheckBtn");

  if(isLocked()){
    const ms = state.lockedUntil - nowTs();
    $("lockTimer").textContent = fmtTime(ms);
    $("lockRule").textContent = "NU (LOCK)";

    $("lockTitle").textContent = "TRADING BLOCKED";
    badge.textContent = "LOCK";
    unlockedShown = false;

    overlay.classList.remove("warn");
    recheck.classList.remove("pulse");
  } else {
    $("lockTimer").textContent = "0s";
    $("lockRule").textContent = "Cooldown finished";

    // AUTO-UNLOCK UX
    if(!unlockedShown){
      unlockedShown = true;
      overlay.classList.add("warn");
      recheck.classList.add("pulse");

      $("lockTitle").textContent = "COOLDOWN FINISHED";
      badge.textContent = "RECHECK";
      $("lockReason").textContent = "Cooldown finished → RECHECK now";
      $("lockHint").textContent = "You’re unlocked. Re-run analysis to get a fresh verdict.";

      // AUTO UNLOCK TOAST
      showToast("Unlocked — Recheck recommended", "warn", 2600);
    }
  }
}

/* -------------------- ANALYZING FLOW -------------------- */
function setStepStatus(elId, status){
  const el = $(elId);
  el.textContent = status;
  el.classList.remove("run","ok","fail");
  if(status === "RUNNING") el.classList.add("run");
  if(status === "DONE") el.classList.add("ok");
  if(status === "FAIL") el.classList.add("fail");
}

function setAnalyzing(active){
  $("calcBtn").disabled = active;
  $("startBtn").disabled = active || $("verdictVal").textContent !== "DA";
  $("blockBtn").disabled = active;
}


/* -------------------- AI TEAM VISUAL -------------------- */
let aiTick = null;
let aiStartTs = 0;

function aiTeamReset(){
  if(aiTick){ clearInterval(aiTick); aiTick = null; }
  aiStartTs = 0;
  const ids = [
    ["mStrategist","sStrategist"],
    ["mAnalyst","sAnalyst"],
    ["mScout","sScout"],
    ["mValidator","sValidator"]
  ];
  ids.forEach(([m,s])=>{
    const el = $(m), st = $(s);
    if(el){ el.classList.remove("working","done","fail"); }
    if(st){ st.textContent = "IDLE"; }
  });
  ["st1","st2","st3","st4"].forEach(id=>{
    const el = $(id);
    if(el) el.classList.remove("active","done","fail");
  });
  ["st1s","st2s","st3s","st4s"].forEach(id=>{
    const el = $(id);
    if(el) el.textContent = "—";
  });
  if($("aiPhase")) $("aiPhase").textContent = "IDLE";
  if($("aiTimer")) $("aiTimer").textContent = "—";
  if($("aiBar")) $("aiBar").style.width = "0%";
  if($("aiNote")) $("aiNote").textContent = "Visual only (pilot). Paste AI notes in Step 2.";
}

function aiSetMember(memberId, statusId, mode, label){
  const m = $(memberId), s = $(statusId);
  if(m){
    m.classList.remove("working","done","fail");
    if(mode) m.classList.add(mode);
  }
  if(s) s.textContent = label;
}

function aiSetStep(stepId, statusId, mode, label){
  const el = $(stepId), st = $(statusId);
  if(el){
    el.classList.remove("active","done","fail");
    if(mode) el.classList.add(mode);
  }
  if(st) st.textContent = label;
}

function aiTeamStart(){
  aiTeamReset();
  aiStartTs = nowTs();
  if($("aiPhase")) $("aiPhase").textContent = "ANALYZING";
  if($("aiNote")) $("aiNote").textContent = "AI TEAM WORKING… (simulated progress UI)";
  // set initial
  aiSetStep("st1","st1s","active","working");
  aiSetMember("mStrategist","sStrategist","working","working");
  aiSetMember("mAnalyst","sAnalyst","working","queued");
  aiSetMember("mScout","sScout","working","queued");
  aiSetMember("mValidator","sValidator","working","queued");

  let p = 0;
  aiTick = setInterval(()=>{
    const ms = nowTs() - aiStartTs;
    if($("aiTimer")) $("aiTimer").textContent = fmtTime(ms);
    p = Math.min(95, (ms/2400)*100); // ~2.4s to 95%
    if($("aiBar")) $("aiBar").style.width = `${p}%`;

    // staged updates
    if(ms > 600){
      aiSetMember("mAnalyst","sAnalyst","working","working");
      aiSetStep("st1","st1s","done","done");
      aiSetStep("st2","st2s","active","working");
    }
    if(ms > 1200){
      aiSetMember("mScout","sScout","working","working");
      aiSetStep("st2","st2s","done","done");
      aiSetStep("st3","st3s","active","working");
    }
    if(ms > 1800){
      aiSetMember("mValidator","sValidator","working","checking");
    }
  }, 120);
}

function aiTeamFinish(ok, note){
  if(aiTick){ clearInterval(aiTick); aiTick = null; }
  const ms = nowTs() - (aiStartTs || nowTs());
  if($("aiTimer")) $("aiTimer").textContent = fmtTime(ms);
  if($("aiBar")) $("aiBar").style.width = "100%";

  if(ok){
    aiSetMember("mStrategist","sStrategist","done","done");
    aiSetMember("mAnalyst","sAnalyst","done","done");
    aiSetMember("mScout","sScout","done","done");
    aiSetMember("mValidator","sValidator","done","done");

    aiSetStep("st3","st3s","done","done");
    aiSetStep("st4","st4s","done","ready");
    if($("aiPhase")) $("aiPhase").textContent = "DONE";
    if($("aiNote")) $("aiNote").textContent = note || "Analysis complete.";
  }else{
    // fail
    aiSetStep("st4","st4s","fail","blocked");
    aiSetMember("mValidator","sValidator","fail","FAIL");
    if($("aiPhase")) $("aiPhase").textContent = "FAIL";
    if($("aiNote")) $("aiNote").textContent = note || "Blocked.";
  }
}

function runAnalyzingFlow(onFinish){
  const start = Date.now();
  const duration = 3200 + Math.floor(Math.random()*1200); // 3.2–4.4 sec
  const tick = 120;

  // reset UI
  $("barFill").style.width = "0%";
  $("analyzeTime").textContent = "—";
  $("analyzeMsg").textContent = "Collecting inputs…";
  $("analyzeMsg").style.color = "var(--muted)";
  setStepStatus("stStrategist","WAIT");
  setStepStatus("stAnalyst","WAIT");
  setStepStatus("stScout","WAIT");
  setStepStatus("stValidator","WAIT");
  setAnalyzing(true);

  setStepStatus("stStrategist","RUNNING");

  const phases = [
    { at: 0.18, msg: "Strategist: checking hard-rules (Edge/Prob)…", do: () => {
      setStepStatus("stStrategist","DONE");
      setStepStatus("stAnalyst","RUNNING");
    }},
    { at: 0.45, msg: "Analyst: micro timing scan (GOOD/WAIT/BAD)…", do: () => {
      setStepStatus("stAnalyst","DONE");
      setStepStatus("stScout","RUNNING");
    }},
    { at: 0.70, msg: "Scout: volatility & event risk check…", do: () => {
      setStepStatus("stScout","DONE");
      setStepStatus("stValidator","RUNNING");
    }},
    { at: 0.88, msg: "Validator: consistency + contradiction check…", do: () => {}}
  ];
  phases.forEach(p => p.done = false);

  const iv = setInterval(() => {
    const p = Math.min(1, (Date.now()-start)/duration);
    $("barFill").style.width = `${Math.floor(p*100)}%`;
    $("analyzeTime").textContent = `${Math.max(0, Math.ceil((duration-(Date.now()-start))/1000))}s`;

    for(const ph of phases){
      if(!ph.done && p >= ph.at){
        ph.done = true;
        $("analyzeMsg").textContent = ph.msg;
        ph.do();
      }
    }

    if(p >= 1){
      clearInterval(iv);

      // IMPORTANT: calc first, then set FAIL/DONE visuals
      const out = calc();
    const ok = out && out.verdict === "DA";
    if(ok) aiTeamFinish(true, `Verdict: DA • ${out.market}/${out.platform}`);
    else aiTeamFinish(false, `Verdict: ${out ? out.verdict : 'NU'} • ${out ? out.reasonNote : 'blocked'}`);

      if(out.verdict === "NU"){
        setStepStatus("stValidator","FAIL");
        const reason = out.reasonNote || "RULE BLOCK";
        $("analyzeMsg").textContent = `BLOCKED BY: ${reason}`;
        $("analyzeMsg").style.color = "var(--bad)";
        showLockOverlay(reason);
      } else {
        setStepStatus("stValidator","DONE");
        $("analyzeMsg").textContent = "Analysis complete. Trade allowed.";
        $("analyzeMsg").style.color = "var(--ok)";
      }

      setAnalyzing(false);
      if(typeof onFinish === "function") onFinish(out);
    }
  }, tick);
}

/* -------------------- MARKET ADAPTIVE ENGINE -------------------- */
const MARKET = {
  NATGAS: {
    label: "NATGAS",
    minEdge: 5,
    minProb: 60,
    blockVol: ["EXTREME"],
    eventVolBlock: { HIGH: ["EXTREME"] },
    delay: { // seconds ranges per edge
      7:[15,30], 6:[30,45], 5:[45,60], 4:[90,90]
    },
    allowMaxSize: true,
    maxSizeRule: { edge:7, prob:70, regime:"FAVORABIL", vol:"NORMAL", validator:true, iqd:6 }
  },
  OIL: {
    label: "OIL",
    minEdge: 5,
    minProb: 62,
    blockVol: ["EXTREME"],
    eventVolBlock: { HIGH: ["HIGH","EXTREME"] },
    delay: { 7:[10,20], 6:[15,30], 5:[25,40], 4:[75,75] },
    allowMaxSize: false, // pilot default (safer)
    maxSizeRule: { edge:7, prob:75, regime:"FAVORABIL", vol:"NORMAL", validator:true, iqd:7 }
  },
  GOLD: {
    label: "GOLD",
    minEdge: 5,
    minProb: 61,
    blockVol: ["EXTREME"],
    eventVolBlock: { HIGH: ["HIGH","EXTREME"] },
    delay: { 7:[10,18], 6:[15,25], 5:[20,35], 4:[75,75] },
    allowMaxSize: false,
    maxSizeRule: { edge:7, prob:75, regime:"FAVORABIL", vol:"NORMAL", validator:true, iqd:7 }
  },
  SPX: {
    label: "SPX",
    minEdge: 5,
    minProb: 60,
    blockVol: ["EXTREME"],
    eventVolBlock: { HIGH: ["EXTREME"] },
    delay: { 7:[8,15], 6:[10,18], 5:[15,25], 4:[60,60] },
    allowMaxSize: false,
    maxSizeRule: { edge:7, prob:75, regime:"FAVORABIL", vol:"NORMAL", validator:true, iqd:7 }
  },
  DXY: {
    label: "DXY",
    minEdge: 5,
    minProb: 60,
    blockVol: ["EXTREME"],
    eventVolBlock: { HIGH: ["EXTREME"] },
    delay: { 7:[10,20], 6:[15,25], 5:[20,35], 4:[75,75] },
    allowMaxSize: false,
    maxSizeRule: { edge:7, prob:75, regime:"FAVORABIL", vol:"NORMAL", validator:true, iqd:7 }
  }
};

function marketCfg(market){
  return MARKET[market] || MARKET.NATGAS;
}

function renderMarketNote(cfg){
  // concise operational note
  const vblock = cfg.blockVol.join(", ");
  const txt = `Market Engine: ${cfg.label} • minEdge=${cfg.minEdge} • minProb=${cfg.minProb}% • blockVol=[${vblock}] • maxSize=${cfg.allowMaxSize ? "POSSIBLE" : "STANDARD ONLY"}`;
  const el = $("marketNote");
  if(el) el.textContent = txt;
}

/* -------------------- ENGINE RULES -------------------- */

function verdictFrom(edge, prob, timing, vol, iqd, consYes, market, eventRisk){
  const missing = [];
  if(edge === null) missing.push("edge");
  if(prob === null) missing.push("prob");
  if(!timing) missing.push("timing");
  if(!vol) missing.push("vol");
  if(iqd === null) missing.push("iqd");

  const dataComplete = missing.length === 0;
  $("dataPill").textContent = dataComplete ? "DATE: COMPLETE" : "DATE: INCOMPLETE";
  $("dataPill").style.color = dataComplete ? "var(--ok)" : "var(--warn)";

  if(!dataComplete) return { verdict:"NU", reason:"DATE INSUFICIENTE", dataComplete:false };

  const cfg = marketCfg(market);
  renderMarketNote(cfg);

  // Market-specific volatility/event blocks
  if(cfg.blockVol.includes(vol)) return { verdict:"NU", reason:`VOLATILITY ${vol} (market block)`, dataComplete:true };
  if(eventRisk && cfg.eventVolBlock && cfg.eventVolBlock[eventRisk]){
    if(cfg.eventVolBlock[eventRisk].includes(vol)) return { verdict:"NU", reason:`EVENT ${eventRisk} + VOL ${vol} (market block)`, dataComplete:true };
  }

  if(isLocked()) return { verdict:"NU", reason:"LOCK ACTIV", dataComplete:true };
  if(timing === "BAD") return { verdict:"NU", reason:"TIMING BAD", dataComplete:true };

  if(iqd < 5) return { verdict:"NU", reason:"IQD < 5", dataComplete:true };
  if(!consYes) return { verdict:"NU", reason:"VALIDATOR NO", dataComplete:true };
  if(prob < cfg.minProb) return { verdict:"NU", reason:`Prob < ${cfg.minProb}%`, dataComplete:true };
  if(edge < cfg.minEdge) return { verdict:"NU", reason:`Edge < ${cfg.minEdge}`, dataComplete:true };

  return { verdict:"DA", reason:"OK", dataComplete:true };
}

function adaptiveDelaySeconds(edge, timing, vol, losses, overtrade, market){
  const cfg = marketCfg(market);
  let base;
  const r = cfg.delay[String(edge)] || cfg.delay[edge];
  if(!r) return null;
  if(r[0] === r[1]) base = r[0];
  else base = randIn(r[0], r[1]);

  if(timing === "WAIT") base += randIn(10,20);
  if(vol === "HIGH") base += randIn(15,30);
  if(losses >= 2) base += 30;
  if(overtrade) base += randIn(30,60);

  return Math.min(base, 180);
}

function positionSize(edge, prob, regime, consYes, vol, iqd, lastLoss, market){
  const standard = "0.005 × 2";
  const max = "0.01 × 2";
  const cfg = marketCfg(market);

  if(vol !== "NORMAL") return standard;
  if(lastLoss) return standard;
  if(iqd < 6) return standard;

  if(cfg.allowMaxSize){
    const r = cfg.maxSizeRule;
    if(edge >= r.edge && prob >= r.prob && regime === r.regime && vol === r.vol && consYes === r.validator && iqd >= r.iqd) return max;
  }
  
  return standard;
}

function evalExit(tp1Hit, peakPct, nowPct, eventRisk, vol){
  if(eventRisk === "HIGH" && vol === "EXTREME"){
    return { action:"CLOSE_ALL", note:"EVENT HIGH + VOL EXTREME → CLOSE (safety)" };
  }

  if(tp1Hit === "NO"){
    return { action:"HOLD", note:"TP1 not hit. Rule: at +8–10% close ≥50% and SL→BE/+1%" };
  }

  const peak = num(peakPct);
  const now = num(nowPct);
  if(peak !== null && now !== null && peak > 0){
    const giveback = (peak - now) / peak;
    if(giveback >= 0.30){
      return { action:"CLOSE_REST", note:`Giveback ${(giveback*100).toFixed(0)}% from peak → CLOSE runner (anti-giveback)` };
    }
  }
  return { action:"HOLD", note:"TP1 done. Runner ON. Trailing ON. Close runner on structure break / giveback." };
}

function qualityTag(iqd, complied){
  if(!complied) return "Q3";
  if(iqd >= 7) return "Q1";
  return "Q2";
}

function randIn(a,b){
  return Math.floor(a + Math.random()*(b-a+1));
}

function num(v){
  const n = Number(v);
  if(Number.isFinite(n)) return n;
  return null;
}

/* -------------------- UI + FLOW -------------------- */

function isLocked(){
  return nowTs() < state.lockedUntil;
}

function setLock(hours){
  state.lockedUntil = nowTs() + hours*3600*1000;
  saveLocks();
  renderLockNote();
}

function clearLock(){
  state.lockedUntil = 0;
  saveLocks();
  renderLockNote();
}

function renderLockNote(){
  if(isLocked()){
    const ms = state.lockedUntil - nowTs();
    $("tradePill").textContent = "LOCKED";
    $("tradePill").style.color = "var(--bad)";
    $("statusNote").textContent = `LOCK active: ${fmtTime(ms)} remaining`;
  }else{
    $("tradePill").textContent = "NO TRADE";
    $("tradePill").style.color = "var(--muted)";
    $("statusNote").textContent = "—";
  }
}

function readInputs(){
  const edge = num($("edgeIn").value);
  const prob = num($("probIn").value);
  const timing = $("timingIn").value;
  const vol = $("volIn").value;
  const regime = $("regimeIn").value;
  const consYes = $("consIn").value === "YES";
  const iqd = num($("iqdIn").value);
  const losses = num($("lossIn").value) ?? 0;
  const overtrade = $("overIn").value === "YES";
  const eventRisk = $("eventIn").value;
  const market = $("marketIn") ? $("marketIn").value : state.market;
  const platform = $("platformIn") ? $("platformIn").value : state.platform;
  return { edge, prob, timing, vol, regime, consYes, iqd, losses, overtrade, eventRisk, market, platform };
}

function renderCalc(out){
  $("edgeVal").textContent = out.edge ?? "—";
  $("probVal").textContent = out.prob !== null ? `${out.prob}%` : "—";
  $("timingVal").textContent = out.timing || "—";
  $("volVal").textContent = out.vol || "—";
  $("regimeVal").textContent = out.regime || "—";

  $("verdictVal").textContent = out.verdict;
  $("verdictVal").style.color = out.verdict === "DA" ? "var(--ok)" : "var(--bad)";

  $("delayVal").textContent = out.delaySec !== null ? `${out.delaySec}s` : "—";
  $("sizeVal").textContent = out.size || "—";

  $("startBtn").disabled = !(out.verdict === "DA");
  $("statusNote").textContent = `${out.reasonNote} • ${out.market || state.market}/${out.platform || state.platform}`;
}

function calc(){
  const inp = readInputs();
  const lastLoss = inp.losses >= 1;
  renderMarketNote(marketCfg(inp.market));
  const v = verdictFrom(inp.edge, inp.prob, inp.timing, inp.vol, inp.iqd, inp.consYes, inp.market, inp.eventRisk);

  // WIZARD HARD GATE: contradiction or missing AI confirmations => NU
  const contraEl = $("contradictionIn");
  const allDoneEl = $("aiAllDone");
  if(contraEl && allDoneEl){
    const contra = contraEl.value === "YES";
    const allDone = allDoneEl.checked;
    if(contra){
      const out = { ...inp, verdict:"NU", delaySec:null, size:"—", reasonNote:"Contradiction = HARD NU", dataComplete:true };
      renderCalc(out);
      return out;
    }
    if(!allDone){
      const out = { ...inp, verdict:"NU", delaySec:null, size:"—", reasonNote:"AI confirmations missing", dataComplete:true };
      renderCalc(out);
      return out;
    }
  }

  let delaySec = null;
  let size = "—";
  let reasonNote = v.reason;

  if(v.verdict === "DA"){
    delaySec = adaptiveDelaySeconds(inp.edge, inp.timing, inp.vol, inp.losses, inp.overtrade, inp.market);
    size = positionSize(inp.edge, inp.prob, inp.regime, inp.consYes, inp.vol, inp.iqd, lastLoss, inp.market);
    reasonNote = `OK • Delay ${delaySec}s • Size ${size}`;
  }else{
    if(v.reason === "LOCK ACTIV"){
      const ms = state.lockedUntil - nowTs();
      reasonNote = `LOCK active: ${fmtTime(ms)} remaining`;
    }
  }

  const out = { ...inp, verdict: v.verdict, delaySec, size, reasonNote, dataComplete: v.dataComplete };
  out = reqHardBlockIfUnconfirmed(out);
  renderCalc(out);
  return out;
}

/* Countdown + 2-step confirm */
function startCountdown(delaySec){
  clearCountdown();
  state.step1Done = false;
  $("countdownBox").hidden = false;
  $("step2Btn").disabled = true;
  $("cdValue").textContent = `${delaySec}s`;
  state.countdownEndsAt = nowTs() + delaySec*1000;

  state.countdown = setInterval(() => {
    const ms = state.countdownEndsAt - nowTs();
    if(ms <= 0){
      $("cdValue").textContent = "0s";
      $("step2Btn").disabled = !state.step1Done;
      clearInterval(state.countdown);
      state.countdown = null;
      return;
    }
    $("cdValue").textContent = fmtTime(ms);
    $("step2Btn").disabled = true;
  }, 250);
}

function clearCountdown(){
  if(state.countdown){
    clearInterval(state.countdown);
    state.countdown = null;
  }
  $("countdownBox").hidden = true;
  $("cdValue").textContent = "—";
  $("step2Btn").disabled = true;
}

function canConfirmNow(){
  return nowTs() >= state.countdownEndsAt;
}

function openTradeConfirmed(){
  $("tradePill").textContent = "READY TO EXECUTE";
  $("tradePill").style.color = "var(--ok)";
  $("exitNote").textContent = "Ready. Use EXECUTION LINK sheet. You execute manually in broker.";
  clearCountdown();
  showExecSheet();
}

/* Exit + Log */
function evalExitUI(){
  const inp = readInputs();
  const tp1Hit = $("tp1In").value;
  const peakPct = $("peakIn").value;
  const nowPct = $("nowIn").value;

  const r = evalExit(tp1Hit, peakPct, nowPct, inp.eventRisk, inp.vol);
  $("exitNote").textContent = `${r.action}: ${r.note}`;
  return r;
}

function closeAndLog(){
  const inp = readInputs();
  const tp1Hit = $("tp1In").value;
  const peak = num($("peakIn").value);
  const now = num($("nowIn").value);

  const complied = (tp1Hit === "YES");
  const qTag = qualityTag(inp.iqd ?? 1, complied);

  const delta = complied ? 0 : -5;

  const entry = num($("entryIn").value);
  const sl = num($("slIn").value);
  const dir = $("dirIn").value;

  const rec = {
    ts: new Date().toISOString(),
    edge: inp.edge,
    prob: inp.prob,
    verdict: $("verdictVal").textContent,
    timing: inp.timing,
    vol: inp.vol,
    regime: inp.regime,
    size: $("sizeVal").textContent,
    delay: $("delayVal").textContent,
    iqd: inp.iqd,
    losses: inp.losses,
    overtrade: inp.overtrade,
    validator: inp.consYes ? "YES" : "NO",
    market: inp.market,
    platform: inp.platform,
    entry,
    sl,
    dir,
    tp1Hit,
    peakPct: peak,
    nowPct: now,
    quality: qTag,
    complied,
    liveProofDeltaPct: delta
  };

  const j = getJournal();
  j.unshift(rec);
  setJournal(j);

  // Adaptive User Engine (pilot): Q3 >= 3 in last 10 => lock 24h
  const last10 = j.slice(0,10);
  const q3 = last10.filter(x => x.quality === "Q3").length;
  if(q3 >= 3){
    setLock(24);
    $("statusNote").textContent = "AUTO LOCK: Q3 ≥ 3 in last 10 trades";
    showLockOverlay("AUTO LOCK: Q3 ≥ 3 in last 10 trades");
  }

  $("tradePill").textContent = "NO TRADE";
  $("tradePill").style.color = "var(--muted)";
  $("exitNote").textContent = `Logged. Quality=${qTag}. LiveProof Δ=${delta}%`;
}

function renderJournal(){
  const j = getJournal();
  $("journalBox").textContent = j.length ? JSON.stringify(j, null, 2) : "";
}

function renderKPI(){
  const j = getJournal();
  const trades = j.length;
  const wins = j.filter(x => (x.nowPct ?? 0) > 0).length;
  const winrate = trades ? Math.round((wins/trades)*100) : 0;
  const q1 = trades ? Math.round((j.filter(x => x.quality==="Q1").length/trades)*100) : 0;
  const exec = trades ? Math.round((j.filter(x => x.complied).length/trades)*100) : 0;

  $("kTradesVal").textContent = String(trades);
  $("kWinVal").textContent = `${winrate}%`;
  $("kQ1Val").textContent = `${q1}%`;
  $("kExecVal").textContent = `${exec}%`;

  $("kpiPill").style.color = exec >= 85 ? "var(--ok)" : (exec >= 60 ? "var(--warn)" : "var(--bad)");
}

function exportJSON(){
  const j = getJournal();
  const blob = new Blob([JSON.stringify(j, null, 2)], { type:"application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `the-survivors-journal-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function resetAll(){
  clearCountdown();
  clearLock();
  const lang = localStorage.getItem(LS.lang) || "ro";
  localStorage.removeItem(keyFor("journal"));
  localStorage.removeItem(keyFor("locks"));
  localStorage.removeItem(keyFor("wizard"));
  localStorage.removeItem(keyFor("ai"));
  localStorage.setItem(LS.lang, lang);
  renderJournal();
  renderKPI();
  renderLockNote();
  $("edgeVal").textContent = "—";
  $("probVal").textContent = "—";
  $("verdictVal").textContent = "—";
  $("timingVal").textContent = "—";
  $("sizeVal").textContent = "—";
  $("delayVal").textContent = "—";
  $("statusNote").textContent = "—";
  $("startBtn").disabled = true;
}

function wizSetStep(step){
  state.wizardStep = step;
  saveWizard();

  const panes = [null, $("pane1"), $("pane2"), $("pane3")];
  panes.forEach((p,i)=>{ if(i>0) p.hidden = (i !== step); });

  // step pills
  const s1 = $("wiz1"), s2 = $("wiz2"), s3 = $("wiz3");
  [s1,s2,s3].forEach(s=>s.classList.remove("active","done"));
  if(step === 1){ s1.classList.add("active"); }
  if(step === 2){ s1.classList.add("done"); s2.classList.add("active"); }
  if(step === 3){ s1.classList.add("done"); s2.classList.add("done"); s3.classList.add("active"); }

  // buttons
  $("wizBack").disabled = (step === 1);
  $("wizNext").hidden = (step === 3);
  $("wizCalc").hidden = (step !== 3);

  // In wizard, prefer calc/open only from step3
  if(step !== 3){
    $("startBtn").disabled = true;
  }

  if(step === 3){
    wizRefreshSummary();
  }
}

function lockInputs(){
  state.inputsLocked = true;
  const ids = ["edgeIn","probIn","timingIn","volIn","regimeIn","consIn","iqdIn","lossIn","overIn","eventIn"];
  ids.forEach(id=>{
    const el = $(id);
    if(el){ el.disabled = true; el.classList.add("lockedField"); }
  });
  $("wizLockPill").style.display = "inline-flex";
  $("wizLockPill").style.color = "var(--warn)";
}

function unlockInputs(){
  state.inputsLocked = false;
  const ids = ["edgeIn","probIn","timingIn","volIn","regimeIn","consIn","iqdIn","lossIn","overIn","eventIn"];
  ids.forEach(id=>{
    const el = $(id);
    if(el){ el.disabled = false; el.classList.remove("lockedField"); }
  });
  $("wizLockPill").style.display = "none";
}

function clearAIConfirmations(){
  if($("aiStrategist")) $("aiStrategist").value = "";
  if($("aiAnalyst")) $("aiAnalyst").value = "";
  if($("aiScout")) $("aiScout").value = "";
  if($("aiValidator")) $("aiValidator").value = "";
  if($("contradictionIn")) $("contradictionIn").value = "NO";
  if($("aiAllDone")) $("aiAllDone").checked = false;
  saveAI({ strategist:"", analyst:"", scout:"", validator:"", contradiction:"NO", allDone:false });
}

function forceBackToStep1(reason){
  // anti-gaming: any input change after lock forces restart
  unlockInputs();
  clearAIConfirmations();
  wizSetStep(1);
  showToast(reason || "Inputs changed → back to Step 1", "warn", 2600);
}

function wizRefreshSummary(){
  const inp = readInputs();
  $("sumEdge").textContent = inp.edge ?? "—";
  $("sumProb").textContent = inp.prob !== null ? `${inp.prob}%` : "—";
  $("sumTiming").textContent = inp.timing || "—";
  $("sumVol").textContent = inp.vol || "—";
  $("sumVal").textContent = inp.consYes ? "YES" : "NO";
  const contra = $("contradictionIn") ? $("contradictionIn").value : "NO";
  $("sumContra").textContent = contra;
}

function wizStep2Valid(){
  const contra = $("contradictionIn").value === "YES";
  const allDone = $("aiAllDone").checked;

  // If contradiction => instantly invalid
  if(contra) return { ok:false, reason:"Contradiction = HARD NU" };

  if(!allDone) return { ok:false, reason:"AI confirmations missing" };

  return { ok:true, reason:"OK" };
}

function persistAIFromUI(){
  const obj = {
    strategist: $("aiStrategist").value || "",
    analyst: $("aiAnalyst").value || "",
    scout: $("aiScout").value || "",
    validator: $("aiValidator").value || "",
    contradiction: $("contradictionIn").value,
    allDone: $("aiAllDone").checked
  };
  saveAI(obj);
}

function hydrateAIToUI(){
  const obj = loadAI();
  if($("aiStrategist")) $("aiStrategist").value = obj.strategist || "";
  if($("aiAnalyst")) $("aiAnalyst").value = obj.analyst || "";
  if($("aiScout")) $("aiScout").value = obj.scout || "";
  if($("aiValidator")) $("aiValidator").value = obj.validator || "";
  if($("contradictionIn")) $("contradictionIn").value = obj.contradiction || "NO";
  if($("aiAllDone")) $("aiAllDone").checked = !!obj.allDone;
}

function wire(){
  $("calcBtn").addEventListener("click", () => {
    // Prefer Wizard: force to Step 3 for calc
    if(state.wizardStep !== 3){
      wizSetStep(3);
      showToast("Wizard: moved to Step 3 (Verdict)", "warn", 1800);
    }
    persistAIFromUI();
    wizRefreshSummary();
    runAnalyzingFlow((out) => {
      if(out && out.verdict !== "DA") renderLockNote();
    });
  });

  $("startBtn").addEventListener("click", () => {
    if(state.wizardStep !== 3){
      showToast("Wizard: go to Step 3 (Verdict) to OPEN", "warn", 2400);
      showLockOverlay("Wizard: OPEN blocked until Step 3");
      return;
    }
    const out = calc();
    const ok = out && out.verdict === "DA";
    if(ok) aiTeamFinish(true, `Verdict: DA • ${out.market}/${out.platform}`);
    else aiTeamFinish(false, `Verdict: ${out ? out.verdict : 'NU'} • ${out ? out.reasonNote : 'blocked'}`);
    if(out.verdict !== "DA") {
      renderLockNote();
      showLockOverlay(out.reasonNote || "RULE BLOCK");
      return;
    }
    startCountdown(out.delaySec);
  });

  // LOCK BUTTON OVERLAY
  $("blockBtn").addEventListener("click", () => {
    setLock(12);
    renderLockNote();
    showLockOverlay("Manual LOCK triggered • Cooldown 12h");
  });

  $("step1Btn").addEventListener("click", () => {
    state.step1Done = true;
    $("step2Btn").disabled = !canConfirmNow();
    $("statusNote").textContent = "STEP 1 done. Waiting countdown…";
  });

  $("step2Btn").addEventListener("click", () => {
    if(!state.step1Done) return;
    if(!canConfirmNow()){
      $("statusNote").textContent = "Too early. Wait countdown.";
      return;
    }
    openTradeConfirmed();
  });

  $("evalExitBtn").addEventListener("click", evalExitUI);
  $("closeBtn").addEventListener("click", closeAndLog);

  $("exportBtn").addEventListener("click", exportJSON);
  $("clearJournalBtn").addEventListener("click", () => {
    localStorage.removeItem(keyFor("journal"));
    renderJournal();
    renderKPI();
  });

  $("resetBtn").addEventListener("click", resetAll);

  $("langSelect").addEventListener("change", async (e) => {
    await loadI18n(e.target.value);
  });

  // WIZARD NAV
  $("wizBack").addEventListener("click", () => {
    persistAIFromUI();
    wizSetStep(Math.max(1, state.wizardStep - 1));
  });

  $("wizNext").addEventListener("click", () => {
    // Step 1 -> 2: require at least Edge+Prob+Timing+Vol+IQD filled
    if(state.wizardStep === 1){
      const inp = readInputs();
      const missing = [];
      if(inp.edge === null) missing.push("edge");
      if(inp.prob === null) missing.push("prob");
      if(!inp.timing) missing.push("timing");
      if(!inp.vol) missing.push("vol");
      if(inp.iqd === null) missing.push("iqd");
      if(missing.length){
        showToast("Fill required inputs before NEXT", "warn", 2200);
        showLockOverlay("Wizard: missing required inputs");
        return;
      }
      wizSetStep(2);
      return;
    }

    // Step 2 -> 3: require no contradiction + AI done checked
    if(state.wizardStep === 2){
      persistAIFromUI();
      const v2 = wizStep2Valid();
      if(!v2.ok){
        showToast(v2.reason, "warn", 2400);
        showLockOverlay(v2.reason);
        return;
      }
      wizSetStep(3);
      return;
    }
  });

  $("wizCalc").addEventListener("click", () => {
    persistAIFromUI();
    wizRefreshSummary();
    runAnalyzingFlow((out) => {
      if(out && out.verdict !== "DA") renderLockNote();
    });
  });

  // Keep summary synced
  ["edgeIn","probIn","timingIn","volIn","regimeIn","consIn","iqdIn","contradictionIn"].forEach(id=>{
    const el = $(id);
    if(el) el.addEventListener("change", () => {
      if(state.inputsLocked){
        forceBackToStep1("Inputs locked — go BACK to Step 1");
        return;
      }
      if(state.wizardStep === 3) wizRefreshSummary();
    });
  });

  $("recheckBtn").addEventListener("click", () => {
    hideLockOverlay();
    runAnalyzingFlow((out) => {
      if(out && out.verdict !== "DA") {
        renderLockNote();
        showLockOverlay(out.reasonNote || "RULE BLOCK");
      }
    });
  });

  $("closeLockBtn").addEventListener("click", () => {
    const overlay = $("lockOverlay");
    const isWarn = overlay.classList.contains("warn");
    hideLockOverlay();
    if(isWarn){
      showToast("Unlocked — Recheck recommended", "warn", 2600);
    }
  
  // REQUIRED APPS
  if($("reqRefreshBtn")) $("reqRefreshBtn").addEventListener("click", () => renderRequirements());

  // EXECUTION SHEET handlers
  ["ex1","ex2","ex3","ex4"].forEach(id => $(id).addEventListener("change", updateExecDoneButton));

  $("openXtbBtn").addEventListener("click", () => {
    const p = (state.platform || ($("platformIn") ? $("platformIn").value : "XTB")).toUpperCase();

    if(p === "XTB"){
      openDeepLink("https://www.xtb.com", "intent://www.xtb.com/#Intent;scheme=https;package=com.xtb.xtb;end");
      return;
    }
    if(p === "MT5"){
      openDeepLink("https://www.metatrader5.com", "intent://www.metatrader5.com/#Intent;scheme=https;package=net.metaquotes.metatrader5;end");
      return;
    }
    if(p === "CTRADER"){
      openDeepLink("https://ct.trader", "intent://ct.trader/#Intent;scheme=https;package=com.spotware.ct;end");
      return;
    }
    if(p === "IBKR"){
      openDeepLink("https://www.interactivebrokers.com", "intent://www.interactivebrokers.com/#Intent;scheme=https;package=com.interactivebrokers.mobile;end");
      return;
    }

    // fallback
    openDeepLink("https://www.xtb.com", null);
  });
  $("openTvBtn").addEventListener("click", () => {
    openDeepLink("https://www.tradingview.com", "intent://www.tradingview.com/#Intent;scheme=https;package=com.tradingview.tradingviewapp;end");
  });
  $("openInvBtn").addEventListener("click", () => {
    openDeepLink("https://www.investing.com", "intent://www.investing.com/#Intent;scheme=https;package=com.fusionmedia.investing;end");
  });

  $("copyTicketBtn").addEventListener("click", async () => {
    const inp = readInputs();
    const entry = $("entryIn").value || "—";
    const sl = $("slIn").value || "—";
    const dir = $("dirIn").value || "—";
    const ticket = [
      "THE SURVIVORS — ORDER TICKET",
      `Profile: ${state.profileName}`,
      `Time: ${new Date().toISOString()}`,
      `Market: ${inp.market || state.market}`,
      `Platform: ${inp.platform || state.platform}`,
      `Direction: ${dir}`,
      `Size: ${$("sizeVal").textContent}`,
      `Entry: ${entry}`,
      `SL: ${sl}`,
      `Rule: TP1 +8–10% close ≥50%, SL→BE/+1%`,
      `Edge: ${inp.edge} | Prob: ${inp.prob}% | Timing: ${inp.timing} | Vol: ${inp.vol}`,
      `AI Confirm: ${($("aiAllDone")?.checked) ? "YES" : "NO"} | Contradiction: ${$("contradictionIn")?.value || "NO"}`
    ].join("\n");
    try{
      await navigator.clipboard.writeText(ticket);
      showToast("Copied order ticket", "warn", 1600);
    }catch{
      showToast("Clipboard blocked (browser). Long-press to copy manually.", "warn", 2200);
    }
  });

  $("execDoneBtn").addEventListener("click", () => {
    // Guard check: if expired, force recheck
    if(guardExpired()){
      hideExecSheet();
      showLockOverlay("Execution guard expired → RECHECK");
      showToast("Guard expired → RECHECK", "warn", 2400);
      return;
    }
    const rec = {
      ts: new Date().toISOString(),
      size: $("sizeVal").textContent,
      entry: $("entryIn").value || null,
      sl: $("slIn").value || null,
      dir: $("dirIn").value,
      edge: $("edgeIn").value || null,
      prob: $("probIn").value || null,
      timing: $("timingIn").value,
      vol: $("volIn").value,
      checklist: { ex1: $("ex1").checked, ex2: $("ex2").checked, ex3: $("ex3").checked, ex4: $("ex4").checked }
    };
    pushExecLog(rec);
    $("tradePill").textContent = "EXECUTED (USER)";
    $("tradePill").style.color = "var(--ok)";
    $("exitNote").textContent = "Execution logged. Now manage position per rules.";
    hideExecSheet();
  });

  $("execCloseBtn").addEventListener("click", () => {
    hideExecSheet();
  });
});
}

function populateProfileSelect(){
  const sel = $("profileSelect");
  const list = loadProfiles();
  sel.innerHTML = "";
  list.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.name;
    sel.appendChild(opt);
  });
}

function applyProfile(profile){
  state.profileId = profile.id;
  state.profileName = profile.name;
  state.market = profile.market || "NATGAS";
  state.platform = profile.platform || "XTB";
  state.mode = profile.mode || "CONSERVATOR";
  state.guardSec = profile.guard || 120;

  // Apply to UI if present
  if($("marketIn")) $("marketIn").value = state.market;
  if($("platformIn")) $("platformIn").value = state.platform;
  renderRequirements();

  // refresh per-profile storages
  loadLocks();
  loadWizard();
  loadPrefs(); // per-profile prefs overrides (optional)
  renderLockNote();
  renderJournal();
  renderKPI();
  hydrateAIToUI();
  wizSetStep(state.wizardStep || 1);

  showToast(`Profile: ${state.profileName}`, "warn", 1400);
}

function createProfileFromCurrent(name){
  const id = "p_" + Math.random().toString(36).slice(2,10);
  return { id, name, market: state.market, platform: state.platform, mode: state.mode, guard: state.guardSec || 120 };
}

function duplicateProfile(){
  const list = loadProfiles();
  const cur = findProfile(list, state.profileId);
  const id = "p_" + Math.random().toString(36).slice(2,10);
  const copy = { ...cur, id, name: cur.name + " (copy)" };
  list.unshift(copy);
  saveProfiles(list);
  return copy;
}

function deleteCurrentProfile(){
  const list = loadProfiles();
  if(list.length <= 1) return null;
  const idx = list.findIndex(p => p.id === state.profileId);
  if(idx >= 0) list.splice(idx,1);
  saveProfiles(list);
  return list[0];
}

function init(){
  aiTeamReset();
  registerSW();

  // Init profiles first (so storage is namespaced)
  const list = loadProfiles();
  const pid = getCurrentProfileId() || (list[0] ? list[0].id : null);
  const prof = findProfile(list, pid || (list[0] ? list[0].id : null));
  state.profileId = prof.id;
  state.profileName = prof.name;
  state.market = prof.market;
  state.platform = prof.platform;
  state.mode = prof.mode || "CONSERVATOR";
  state.guardSec = prof.guard || 120;

  loadLocks();
  loadWizard();
  loadPrefs();
  renderLockNote();
  renderJournal();
  renderKPI();

  const savedLang = localStorage.getItem(LS.lang) || "ro";
  $("langSelect").value = savedLang;
  loadI18n(savedLang).catch(()=>{});

  // Apply saved market/platform to UI
  if($("marketIn")) $("marketIn").value = state.market;
  if($("platformIn")) $("platformIn").value = state.platform;

  hydrateAIToUI();
  wizSetStep(state.wizardStep || 1);
  renderRequirements();

  wire();
}

window.addEventListener("load", init);
